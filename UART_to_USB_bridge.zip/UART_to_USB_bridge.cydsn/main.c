/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
uint8 rxData;

CY_ISR( recv_from_spresense_handler )
{
    while(UART_withSPRESENSE_GetRxBufferSize())
    {
        rxData = UART_withSPRESENSE_GetChar();
        UART_PC_PutChar(rxData);
    }
//    recv_from_spresense_int_ClearPending();
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    UART_PC_Start();
    UART_withSPRESENSE_Start();
//    recv_from_spresense_int_StartEx( recv_from_spresense_handler );

    for(;;)
    {
        while(UART_withSPRESENSE_GetRxBufferSize())
        {
            UART_PC_PutChar(UART_withSPRESENSE_GetChar());
        }
    }
}

/* [] END OF FILE */
